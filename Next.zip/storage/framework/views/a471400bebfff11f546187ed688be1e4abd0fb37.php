<form method="post" action="<?php echo e(route('addbox')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="number" name="id" placeholder="id"><br><br>
    <input type="text" name="name" placeholder="name"><br><br>
    <input type="file" name="image1" placeholder="image1"><br><br>


    <input type="text" name="dimentions" placeholder="dim"><br><br>
    <input type="number" name="price_conter" placeholder="pcon"><br><br>
    <input type="number" name="price_mdf" placeholder="pmdf"><br><br>
    <input type="text" name="type" placeholder="up or down"><br><br>
    <input type="submit" value="submit" >

</form>
<?php /**PATH C:\Laravel-projects\Next\resources\views/index.blade.php ENDPATH**/ ?>